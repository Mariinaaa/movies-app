import React, { useState, useEffect } from 'react';
import MovieCard from '../components/MovieCard';

const API_KEY = process.env.REACT_APP_TMDB_API_KEY;
const BASE_URL = 'https://api.themoviedb.org/3';

const Home = () => {
  const [movies, setMovies] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [loading, setLoading] = useState(false);

  // Cargar películas populares al montar
  useEffect(() => {
    fetchPopularMovies();
  }, []);

  // Obtener películas populares
  const fetchPopularMovies = async () => {
    setLoading(true);
    const res = await fetch(`${BASE_URL}/movie/popular?api_key=${API_KEY}`);
    const data = await res.json();
    setMovies(data.results);
    setLoading(false);
  };

  // Buscar películas
  const searchMovies = async (e) => {
    e.preventDefault();
    if (!searchQuery) return fetchPopularMovies();

    setLoading(true);
    const res = await fetch(`${BASE_URL}/search/movie?api_key=${API_KEY}&query=${searchQuery}`);
    const data = await res.json();
    setMovies(data.results);
    setLoading(false);
  };

  return (
    <div className="home">
      <form onSubmit={searchMovies} className="search-form">
        <input
          type="text"
          placeholder="Buscar películas..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
        />
        <button type="submit">Buscar</button>
      </form>

      {loading ? (
        <p>Cargando...</p>
      ) : (
        <div className="movies-grid">
          {movies.map((movie) => (
            <MovieCard key={movie.id} movie={movie} />
          ))}
        </div>
      )}
    </div>
  );
};

export default Home;
