import React from 'react';
import { useMovies } from '../context/MovieContext';
import MovieCard from '../components/MovieCard';

const Favorites = () => {
  const { favorites } = useMovies();

  if (favorites.length === 0) {
    return <p>No tienes películas favoritas aún.</p>;
  }

  return (
    <div className="movies-grid">
      {favorites.map((movie) => (
        <MovieCard key={movie.id} movie={movie} />
      ))}
    </div>
  );
};

export default Favorites;
