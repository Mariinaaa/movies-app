import React, { createContext, useContext, useState, useEffect } from "react";

const MovieContext = createContext();

export const MovieProvider = ({ children }) => {
  // Inicializa directamente leyendo de localStorage
  const [favorites, setFavorites] = useState(() => {
    const stored = localStorage.getItem("favorites");
    return stored ? JSON.parse(stored) : [];
  });

  // Guarda cada cambio en localStorage
  useEffect(() => {
    localStorage.setItem("favorites", JSON.stringify(favorites));
  }, [favorites]);

  // Alterna favoritos (añade o quita)
  const toggleFavorite = (movie) => {
    if (!movie || !movie.id) return;

    setFavorites((prevFavorites) => {
      const exists = prevFavorites.some((fav) => fav.id === movie.id);
      return exists
        ? prevFavorites.filter((fav) => fav.id !== movie.id)
        : [...prevFavorites, movie];
    });
  };

  // Devuelve contexto global
  return (
    <MovieContext.Provider value={{ favorites, toggleFavorite }}>
      {children}
    </MovieContext.Provider>
  );
};

// Hook personalizado para acceder al contexto
export const useMovies = () => useContext(MovieContext);
