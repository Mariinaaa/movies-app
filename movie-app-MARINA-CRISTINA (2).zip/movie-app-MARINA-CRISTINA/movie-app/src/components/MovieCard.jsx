import React from 'react';
import { useMovies } from '../context/MovieContext';
import './MovieCard.css'; // (opcional para estilos)

const MovieCard = ({ movie }) => {
  const { favorites, toggleFavorite } = useMovies();
  const isFavorite = favorites.some(m => m.id === movie.id);

  return (
    <div className="movie-card">
      <img
        src={`https://image.tmdb.org/t/p/w500${movie.poster_path}`}
        alt={movie.title}
      />
      <div className="info">
        <h3>{movie.title}</h3>
        <p>{movie.release_date ? new Date(movie.release_date).getFullYear() : 'N/A'}</p>
        <button onClick={() => toggleFavorite(movie)}>
          {isFavorite ? '❤️' : '🤍'}
        </button>
      </div>
    </div>
  );
};

export default MovieCard;
