import { Link } from 'react-router-dom';
import './NavBar.css'; // (opcional, para tus estilos)

const NavBar = () => {
  return (
    <nav className="navbar">
      <h1> MovieApp</h1>
      <div className="links">
        <Link to="/">Home</Link>
        <Link to="/favorites">Favorites</Link>
      </div>
    </nav>
  );
};

export default NavBar;
